close all

f=figure;
% f.Position = [];
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

nexttile(1)
plot(TOTPFD,reshape(An,7,3))
hold on
plot(TOTPFD,reshape(Anobs,7,3),'o:')
ax = gca;
ax.ColorOrder = [0 0 1; 0 1 0; 1 0 0];
ylabel('A_n (\mumol CO_2 m^{-2} s^{-1})')
title('a)')

nexttile(2)
plot(TOTPFD,reshape(1.64e-06*gsCO2,7,3))
hold on
plot(TOTPFD,reshape(gsobs,7,3),'o:')
ax = gca;
ax.ColorOrder = [0 0 1; 0 1 0; 1 0 0];
ylabel('g_S (mol H_2O m^{-2} s^{-1})')
title('c)')

nexttile(3)
plot(TOTPFD,reshape(Tr,7,3))
hold on
plot(TOTPFD,reshape(Tobs,7,3),'o:')
ax = gca;
ax.ColorOrder = [0 0 1; 0 1 0; 1 0 0];
ylabel('T (mmol H_2O m^{-2} s^{-1})')
xlabel('PPFD (\mumol m^{-2} s^{-1})')
title('b)')

nexttile(4)
plot(TOTPFD,reshape(CiF,7,3))
hold on
plot(TOTPFD,reshape(Cobs,7,3),'o:')
ax = gca;
ax.ColorOrder = [0 0 1; 0 1 0; 1 0 0];
ylabel('C_i (\mumol CO_2 mol^{-1})')
xlabel('PPFD (\mumol m^{-2} s^{-1})')
title('d)')
