%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SPECTRA-AWARE PHOTOSYNTHESIS MODEL %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% search tradeoff between gs and An %%
close all
clear all

Anobs=csvread('Anobs.csv',0,1);
gsobs=csvread('gsobs.csv',0,1);
Tobs=csvread('Tobs.csv',0,1);
Anobs=flipud(Anobs);
gsobs=flipud(gsobs);
Tobs=Tobs./1000./1000./86400./(pi*0.10^2/4);

global Anobs gsobs Tobs

tic ;

fun = @(x)parfun(x);
bestx=load('bestx_joint.txt');
options = optimoptions('paretosearch','PlotFcn','psplotparetof','InitialPoints',bestx);
bl=[ 75 1.50    1 0.0  10 0.70 0.20];
bu=[300 2.50  600 1.0 300 0.90 0.80];
rng default % For reproducibility
% rng('shuffle')
[z,fval] = paretosearch(fun,7,[],[],[],[],bl,bu,[],options);
% WUE=GPP./(T.*1.0e6.*86400);
%close(bau)
Computational_Time = toc;
%profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('COMPUTATIONAL TIME [s] ')
disp(Computational_Time)

