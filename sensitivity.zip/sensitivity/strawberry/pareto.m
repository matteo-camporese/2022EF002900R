%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SPECTRA-AWARE PHOTOSYNTHESIS MODEL %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% search tradeoff between WUE and An %%
close all
clear all
I=[50;55;60;70;80;100;70;95];
tic ;

for i=1:8
    fun = @(x)parfun(x,i);
    options = optimoptions('paretosearch','PlotFcn','psplotparetof','MaxIterations',1000);
    % lb = [23,60,405,100];
    % ub = [26,80,520,500];
    % lb = [30,40,405,I(i)];
    % ub = [40,60,520,500];
    lb = [0,10];
    ub = [40,500];
    rng default % For reproducibility
    % rng('shuffle')
    [z,fval] = paretosearch(fun,2,[],[],[],[],lb,ub,[],options);
    fval=-1*fval;
    filename=['pareto_lt',int2str(i)];
    save(filename)
end
% WUE=GPP./(T.*1.0e6.*86400);
%close(bau)
Computational_Time = toc;
%profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('COMPUTATIONAL TIME [s] ')
disp(Computational_Time)

