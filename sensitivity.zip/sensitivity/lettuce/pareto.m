%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SPECTRA-AWARE PHOTOSYNTHESIS MODEL %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% search tradeoff between WUE and An %%
close all
clear all
I=[55;55;65;75;85;100;80;110];
tic ;

for i=1:8
    fun = @(x)parfun(x,i);
    options = optimoptions('paretosearch','PlotFcn','psplotparetof','MaxIterations',1000);
    %lb = [23,60,405,10];
    %ub = [26,80,520,80];
    %lb = [23,60,405,I(i)+5];
    %ub = [26,80,520,500];
    lb = [0,10];
    ub = [40,500];
    rng default % For reproducibility
    % rng('shuffle')
    [z,fval] = paretosearch(fun,2,[],[],[],[],lb,ub,[],options);
    fval=-1*fval;
    filename=['pareto_lt',int2str(i)];
    save(filename)
end
% WUE=GPP./(T.*1.0e6.*86400);
%close(bau)
Computational_Time = toc;
%profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('COMPUTATIONAL TIME [s] ')
disp(Computational_Time)

